export interface Aluno{
    ra?: String,
    nome: String,
    dataCadastro: Date,
    ativo: Boolean
  }
