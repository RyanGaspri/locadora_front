import { Component, OnInit } from '@angular/core';
import { Aluno } from 'src/app/entities/aluno';
@Component({
 selector: 'app-read-all',
 templateUrl: './read-all.component.html',
 styleUrls: ['./read-all.component.scss']
})
export class ReadAllComponent implements OnInit {
  list: Aluno[] = [
      {
       nome: "Silvio Santo",
       dataCadastro: new Date,
       ativo: false
      },
      {
        nome: "Rodrigo Farias",
        dataCadastro: new Date,
        ativo: false
      }
     ]

 constructor() { }
 ngOnInit(): void {
 }
}


